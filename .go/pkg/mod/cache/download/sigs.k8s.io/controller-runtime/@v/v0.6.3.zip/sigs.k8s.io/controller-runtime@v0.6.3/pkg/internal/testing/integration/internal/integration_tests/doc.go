/*
Package integrationtests holds the integration tests to run against the
framework.

This file's only purpose is to make godep happy.
*/
package integrationtests
